package proyectozoologico;


public class ProyectoZoologico {


    public static void main(String[] args) {
        
            Zoologico zoo = new Zoologico("ZooWorld");
        
            Animal leon = new Mamifero("Leon", 3, 155.0, TipoDieta.CARNIVORO);
            Animal otroleon = new Mamifero("Leon", 3, 155.0, TipoDieta.CARNIVORO); 
            Animal tigre = new Mamifero("Tigre", 5, 200, TipoDieta.CARNIVORO);
            Animal loro = new Ave("Loro", 9, 1.5, TipoDieta.OMNIVORO, 10.0);
            Animal iguana = new Reptil("Iguana", 4, 1.2, TipoDieta.HERBIVORO, "Escama suave", "Templada");
            Animal tigre2 = new Mamifero("Tigre", 4, 200.0, TipoDieta.CARNIVORO);
            Animal pavoreal = new Ave("Pavo Real", 6, 5.5, TipoDieta.HERBIVORO, 200.0);

            
            try{
                zoo.agregarAnimal(leon);
                zoo.agregarAnimal(tigre);
                zoo.agregarAnimal(loro);
                zoo.agregarAnimal(iguana);
                zoo.agregarAnimal(tigre2);
                zoo.agregarAnimal(null);
                zoo.agregarAnimal(pavoreal);
                zoo.agregarAnimal(otroleon);
            }
            catch(NullPointerException ex){
                System.out.println("Se paso un valor nulo");
            }
            catch(AnimalExistenteException ex){
                System.out.println(ex.getMessage());
            }
            
            zoo.listarAnimales();
            zoo.vacunarAnimal();
            

    }
    
}
