package proyectozoologico;


public enum TipoDieta {
    
    HERBIVORO,
    CARNIVORO,
    OMNIVORO
    
}
