package proyectozoologico;

import java.util.ArrayList;
import java.util.List;


public class Zoologico {
    
    private String nombreZoo;
    private List <Animal> animales;

    public Zoologico(String nombreZoo) {
        this.nombreZoo = nombreZoo;
        animales = new ArrayList <>();
    }
    
    public void agregarAnimal(Animal animal){
        for (Animal a: animales){
            if(a.getNombre().equals(animal.getNombre()) && a.getEdad() == animal.getEdad()){
                throw new AnimalExistenteException ();
            }
            if(animal == null){
                throw new NullPointerException();
            }
        }
        animales.add(animal);
    }
    
    public void listarAnimales(){
        if (animales.isEmpty()){
            System.out.println("No hay animales para mostrar");
        }else{
            for (Animal a: animales){
                System.out.println(a);
            }
        }
    }
    
    public void vacunarAnimal(){
        for(Animal a: animales){
            if(a instanceof Vacunacion){
                ((Vacunacion)a).vacunar();
                
            }else{
                System.out.println(a.getNombre() + "no se puede vacunar");
            }
        }
        
    }
    
    
}
