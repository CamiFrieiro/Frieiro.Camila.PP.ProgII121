package proyectozoologico;


public class Reptil extends Animal{
    
    private String tipoEscama;
    private String regulacionTemperatura;

    public Reptil(String nombre, int edad, double peso, TipoDieta tipoDieta, String tipoEscama, String regulacionTemperatura) {
        super(nombre, edad, peso, tipoDieta);
        this.tipoEscama = tipoEscama;
        this.regulacionTemperatura = regulacionTemperatura;
    }

    @Override
    public String toString() {
        return "Reptil:" + "\n" + "[Tipo de Escama: " + tipoEscama + ", Regulacion de Temperatura: " + regulacionTemperatura + "]";
    }


}
