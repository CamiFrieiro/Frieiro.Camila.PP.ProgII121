
package proyectozoologico;


public class Ave extends Animal implements Vacunacion {
    
    private double envergaduraAlas;

    public Ave(String nombre, int edad, double peso, TipoDieta tipoDieta, double envergaduraAlas) {
        super(nombre, edad, peso, tipoDieta);
        this.envergaduraAlas = envergaduraAlas;
    }
    
    

    @Override
    public void vacunar() {
        System.out.println("El ave fue vacunado");
        
    }

    @Override
    public String toString() {
        return "Ave:" + "\n" + "[Envergadura de Alas:" + envergaduraAlas + "cm.]";
    }
   
    
}
