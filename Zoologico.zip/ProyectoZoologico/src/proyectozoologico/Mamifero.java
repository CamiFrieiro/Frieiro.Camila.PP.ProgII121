package proyectozoologico;


public class Mamifero extends Animal implements Vacunacion {

    public Mamifero(String nombre, int edad, double peso, TipoDieta tipoDieta) {
        super(nombre, edad, peso, tipoDieta);
    }
    

    @Override
    public void vacunar() {
        System.out.println("El Mamifero fue vacunado");
    }

    @Override
    public String toString() {
         return "Mamifero:" + "\n" + "[Peso: " + getPeso() + ", Dieta:" + getTipoDieta() + "]";
    }


}
