package proyectozoologico;

public class AnimalExistenteException extends RuntimeException {
    
    private final static String MESSAGE = "El animal ya existe";
    
    public AnimalExistenteException(){
        super(MESSAGE);
    }
    
}

    