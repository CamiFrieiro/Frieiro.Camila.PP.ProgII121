package proyectozoologico;


public abstract class Animal {
    
    private String nombre;
    private int edad;
    private double peso;
    private TipoDieta tipoDieta;

    public Animal(String nombre, int edad, double peso, TipoDieta tipoDieta) {
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
        this.tipoDieta = tipoDieta;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public double getPeso() {
        return peso;
    }

    public TipoDieta getTipoDieta() {
        return tipoDieta;
    }

    @Override
    public String toString() {
        return "Animal:" + "\n" + "[Nombre: " + nombre + ", Edad: " + edad + ", Peso: " + peso + ", Tipo de Dieta: " + tipoDieta + ']';
    }
    
    
    
}
