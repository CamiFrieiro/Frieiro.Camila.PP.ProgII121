package proyectozoologico;


public interface Vacunacion {
    
    void vacunar();
    
}
